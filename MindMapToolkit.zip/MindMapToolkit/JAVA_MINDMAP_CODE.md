# Java MindMap Console Implementation

## About the Java Code
The Java implementation mentioned in your project description is a console-based version of the mind mapping tool. Here's the complete implementation:

## Project Structure
```
MindMapConsole/
│
├── src/
│   ├── Main.java
│   ├── model/
│   │   ├── IdeaNode.java
│   │   ├── GoalNode.java
│   │   ├── QuestionNode.java
│   │   └── NoteNode.java
│   ├── core/
│   │   ├── MindMap.java
│   │   └── MapExplorer.java
│   └── util/
│       └── MapStorage.java
│
├── data/
│   └── sample_map.txt
│
├── README.md
└── .gitignore
```

## Core Java Classes

### 1. IdeaNode.java (Base Node Class)
```java
package model;

import java.util.*;
import java.time.LocalDateTime;

public class IdeaNode {
    protected String title;
    protected String description;
    protected List<String> tags;
    protected List<IdeaNode> connections;
    protected LocalDateTime createdAt;
    protected LocalDateTime updatedAt;
    
    public IdeaNode(String title, String description) {
        this.title = title;
        this.description = description;
        this.tags = new ArrayList<>();
        this.connections = new ArrayList<>();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    public void addConnection(IdeaNode node) {
        if (!connections.contains(node)) {
            connections.add(node);
            node.connections.add(this);
        }
    }
    
    public void removeConnection(IdeaNode node) {
        connections.remove(node);
        node.connections.remove(this);
    }
    
    public List<IdeaNode> getConnections() {
        return new ArrayList<>(connections);
    }
    
    public void addTag(String tag) {
        if (!tags.contains(tag)) {
            tags.add(tag);
        }
    }
    
    // Getters and Setters
    public String getTitle() { return title; }
    public void setTitle(String title) { 
        this.title = title; 
        this.updatedAt = LocalDateTime.now();
    }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { 
        this.description = description; 
        this.updatedAt = LocalDateTime.now();
    }
    
    public List<String> getTags() { return new ArrayList<>(tags); }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    
    @Override
    public String toString() {
        return String.format("[%s] %s - %s", 
            this.getClass().getSimpleName().replace("Node", ""), 
            title, description);
    }
}
```

### 2. Specialized Node Classes

#### GoalNode.java
```java
package model;

public class GoalNode extends IdeaNode {
    private boolean isCompleted;
    private String deadline;
    
    public GoalNode(String title, String description) {
        super(title, description);
        this.isCompleted = false;
    }
    
    public boolean isCompleted() { return isCompleted; }
    public void setCompleted(boolean completed) { 
        this.isCompleted = completed; 
        setUpdatedAt(LocalDateTime.now());
    }
    
    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }
}
```

#### QuestionNode.java
```java
package model;

public class QuestionNode extends IdeaNode {
    private boolean isAnswered;
    private String answer;
    
    public QuestionNode(String title, String description) {
        super(title, description);
        this.isAnswered = false;
    }
    
    public boolean isAnswered() { return isAnswered; }
    public String getAnswer() { return answer; }
    
    public void setAnswer(String answer) {
        this.answer = answer;
        this.isAnswered = true;
        setUpdatedAt(LocalDateTime.now());
    }
}
```

#### NoteNode.java
```java
package model;

public class NoteNode extends IdeaNode {
    private String category;
    
    public NoteNode(String title, String description) {
        super(title, description);
    }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}
```

### 3. MindMap.java (Core Management)
```java
package core;

import model.*;
import java.util.*;

public class MindMap {
    private Map<String, IdeaNode> nodes;
    private String name;
    
    public MindMap(String name) {
        this.name = name;
        this.nodes = new HashMap<>();
    }
    
    public void addNode(IdeaNode node) {
        nodes.put(node.getTitle(), node);
    }
    
    public void removeNode(String title) {
        IdeaNode node = nodes.get(title);
        if (node != null) {
            // Remove all connections
            for (IdeaNode connected : node.getConnections()) {
                connected.removeConnection(node);
            }
            nodes.remove(title);
        }
    }
    
    public IdeaNode findNode(String title) {
        return nodes.get(title);
    }
    
    public List<IdeaNode> getAllNodes() {
        return new ArrayList<>(nodes.values());
    }
    
    public List<IdeaNode> searchNodes(String keyword) {
        List<IdeaNode> results = new ArrayList<>();
        keyword = keyword.toLowerCase();
        
        for (IdeaNode node : nodes.values()) {
            if (node.getTitle().toLowerCase().contains(keyword) ||
                node.getDescription().toLowerCase().contains(keyword) ||
                node.getTags().stream().anyMatch(tag -> 
                    tag.toLowerCase().contains(keyword))) {
                results.add(node);
            }
        }
        return results;
    }
    
    public Map<String, Integer> getNodeStatistics() {
        Map<String, Integer> stats = new HashMap<>();
        for (IdeaNode node : nodes.values()) {
            String type = node.getClass().getSimpleName();
            stats.put(type, stats.getOrDefault(type, 0) + 1);
        }
        return stats;
    }
}
```

### 4. MapExplorer.java (Navigation)
```java
package core;

import model.*;
import java.util.*;

public class MapExplorer {
    private MindMap mindMap;
    
    public MapExplorer(MindMap mindMap) {
        this.mindMap = mindMap;
    }
    
    public void navigate(String startNodeTitle) {
        IdeaNode startNode = mindMap.findNode(startNodeTitle);
        if (startNode == null) {
            System.out.println("Node not found: " + startNodeTitle);
            return;
        }
        
        System.out.println("Starting from: " + startNode);
        printConnections(startNode, new HashSet<>(), 0);
    }
    
    private void printConnections(IdeaNode node, Set<IdeaNode> visited, int depth) {
        if (visited.contains(node) || depth > 3) return;
        
        visited.add(node);
        String indent = "  ".repeat(depth);
        
        System.out.println(indent + "→ " + node);
        
        for (IdeaNode connected : node.getConnections()) {
            printConnections(connected, visited, depth + 1);
        }
    }
    
    public List<IdeaNode> findPath(String startTitle, String endTitle) {
        IdeaNode start = mindMap.findNode(startTitle);
        IdeaNode end = mindMap.findNode(endTitle);
        
        if (start == null || end == null) return new ArrayList<>();
        
        Queue<List<IdeaNode>> queue = new LinkedList<>();
        Set<IdeaNode> visited = new HashSet<>();
        
        queue.offer(Arrays.asList(start));
        visited.add(start);
        
        while (!queue.isEmpty()) {
            List<IdeaNode> path = queue.poll();
            IdeaNode current = path.get(path.size() - 1);
            
            if (current.equals(end)) {
                return path;
            }
            
            for (IdeaNode neighbor : current.getConnections()) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    List<IdeaNode> newPath = new ArrayList<>(path);
                    newPath.add(neighbor);
                    queue.offer(newPath);
                }
            }
        }
        
        return new ArrayList<>();
    }
}
```

### 5. MapStorage.java (File I/O)
```java
package util;

import core.MindMap;
import model.*;
import java.io.*;
import java.util.*;

public class MapStorage {
    
    public static void save(MindMap mindMap, String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println("# MindMap: " + mindMap.getName());
            writer.println("# Generated: " + java.time.LocalDateTime.now());
            writer.println();
            
            // Save nodes
            for (IdeaNode node : mindMap.getAllNodes()) {
                writer.println("NODE:" + node.getClass().getSimpleName() + 
                             "|" + node.getTitle() + 
                             "|" + node.getDescription() + 
                             "|" + String.join(",", node.getTags()));
            }
            
            writer.println();
            
            // Save connections
            Set<String> savedConnections = new HashSet<>();
            for (IdeaNode node : mindMap.getAllNodes()) {
                for (IdeaNode connected : node.getConnections()) {
                    String connection = node.getTitle() + "->" + connected.getTitle();
                    String reverseConnection = connected.getTitle() + "->" + node.getTitle();
                    
                    if (!savedConnections.contains(reverseConnection)) {
                        writer.println("CONNECTION:" + connection);
                        savedConnections.add(connection);
                    }
                }
            }
            
            System.out.println("Mind map saved to: " + filename);
        } catch (IOException e) {
            System.err.println("Error saving mind map: " + e.getMessage());
        }
    }
    
    public static MindMap load(String filename) {
        MindMap mindMap = new MindMap("Loaded Map");
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;
                
                if (line.startsWith("NODE:")) {
                    String[] parts = line.substring(5).split("\\|");
                    if (parts.length >= 3) {
                        String nodeType = parts[0];
                        String title = parts[1];
                        String description = parts[2];
                        String[] tags = parts.length > 3 ? parts[3].split(",") : new String[0];
                        
                        IdeaNode node = createNodeByType(nodeType, title, description);
                        for (String tag : tags) {
                            if (!tag.trim().isEmpty()) {
                                node.addTag(tag.trim());
                            }
                        }
                        mindMap.addNode(node);
                    }
                }
                
                if (line.startsWith("CONNECTION:")) {
                    String[] parts = line.substring(11).split("->");
                    if (parts.length == 2) {
                        IdeaNode node1 = mindMap.findNode(parts[0]);
                        IdeaNode node2 = mindMap.findNode(parts[1]);
                        if (node1 != null && node2 != null) {
                            node1.addConnection(node2);
                        }
                    }
                }
            }
            
            System.out.println("Mind map loaded from: " + filename);
        } catch (IOException e) {
            System.err.println("Error loading mind map: " + e.getMessage());
        }
        
        return mindMap;
    }
    
    private static IdeaNode createNodeByType(String type, String title, String description) {
        switch (type) {
            case "GoalNode": return new GoalNode(title, description);
            case "QuestionNode": return new QuestionNode(title, description);
            case "NoteNode": return new NoteNode(title, description);
            default: return new IdeaNode(title, description);
        }
    }
}
```

### 6. Main.java (Console Interface)
```java
import core.*;
import model.*;
import util.*;
import java.util.*;

public class Main {
    private static MindMap mindMap = new MindMap("My Mind Map");
    private static MapExplorer explorer = new MapExplorer(mindMap);
    private static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        System.out.println("=== MindMap Console ===");
        System.out.println("Welcome to your digital mind mapping tool!");
        
        boolean running = true;
        while (running) {
            showMenu();
            String choice = scanner.nextLine().trim();
            
            switch (choice) {
                case "1": addNode(); break;
                case "2": linkNodes(); break;
                case "3": viewNode(); break;
                case "4": searchNodes(); break;
                case "5": exploreMap(); break;
                case "6": showStatistics(); break;
                case "7": saveMap(); break;
                case "8": loadMap(); break;
                case "9": running = false; break;
                default: System.out.println("Invalid choice. Please try again.");
            }
        }
        
        System.out.println("Goodbye!");
    }
    
    private static void showMenu() {
        System.out.println("\n=== Main Menu ===");
        System.out.println("1. Add Node");
        System.out.println("2. Link Nodes");
        System.out.println("3. View Node");
        System.out.println("4. Search Nodes");
        System.out.println("5. Explore Map");
        System.out.println("6. Show Statistics");
        System.out.println("7. Save Map");
        System.out.println("8. Load Map");
        System.out.println("9. Exit");
        System.out.print("Choose an option: ");
    }
    
    private static void addNode() {
        System.out.println("\n=== Add New Node ===");
        System.out.println("1. Idea  2. Goal  3. Question  4. Note");
        System.out.print("Node type: ");
        String type = scanner.nextLine().trim();
        
        System.out.print("Title: ");
        String title = scanner.nextLine().trim();
        
        System.out.print("Description: ");
        String description = scanner.nextLine().trim();
        
        IdeaNode node;
        switch (type) {
            case "2": node = new GoalNode(title, description); break;
            case "3": node = new QuestionNode(title, description); break;
            case "4": node = new NoteNode(title, description); break;
            default: node = new IdeaNode(title, description); break;
        }
        
        System.out.print("Tags (comma-separated): ");
        String tagsInput = scanner.nextLine().trim();
        if (!tagsInput.isEmpty()) {
            for (String tag : tagsInput.split(",")) {
                node.addTag(tag.trim());
            }
        }
        
        mindMap.addNode(node);
        System.out.println("Node added successfully!");
    }
    
    private static void linkNodes() {
        System.out.println("\n=== Link Nodes ===");
        System.out.print("First node title: ");
        String title1 = scanner.nextLine().trim();
        
        System.out.print("Second node title: ");
        String title2 = scanner.nextLine().trim();
        
        IdeaNode node1 = mindMap.findNode(title1);
        IdeaNode node2 = mindMap.findNode(title2);
        
        if (node1 != null && node2 != null) {
            node1.addConnection(node2);
            System.out.println("Nodes linked successfully!");
        } else {
            System.out.println("One or both nodes not found.");
        }
    }
    
    private static void viewNode() {
        System.out.print("Node title: ");
        String title = scanner.nextLine().trim();
        
        IdeaNode node = mindMap.findNode(title);
        if (node != null) {
            System.out.println("\n" + node);
            System.out.println("Tags: " + node.getTags());
            System.out.println("Connections: " + 
                node.getConnections().stream()
                    .map(IdeaNode::getTitle)
                    .reduce((a, b) -> a + ", " + b)
                    .orElse("None"));
        } else {
            System.out.println("Node not found.");
        }
    }
    
    private static void searchNodes() {
        System.out.print("Search keyword: ");
        String keyword = scanner.nextLine().trim();
        
        List<IdeaNode> results = mindMap.searchNodes(keyword);
        if (results.isEmpty()) {
            System.out.println("No nodes found.");
        } else {
            System.out.println("\nSearch Results:");
            for (IdeaNode node : results) {
                System.out.println("- " + node);
            }
        }
    }
    
    private static void exploreMap() {
        System.out.print("Starting node title: ");
        String title = scanner.nextLine().trim();
        explorer.navigate(title);
    }
    
    private static void showStatistics() {
        Map<String, Integer> stats = mindMap.getNodeStatistics();
        System.out.println("\n=== Mind Map Statistics ===");
        System.out.println("Total nodes: " + mindMap.getAllNodes().size());
        for (Map.Entry<String, Integer> entry : stats.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
    
    private static void saveMap() {
        System.out.print("Filename (e.g., my_mindmap.txt): ");
        String filename = scanner.nextLine().trim();
        MapStorage.save(mindMap, "data/" + filename);
    }
    
    private static void loadMap() {
        System.out.print("Filename: ");
        String filename = scanner.nextLine().trim();
        mindMap = MapStorage.load("data/" + filename);
        explorer = new MapExplorer(mindMap);
    }
}
```

## How to Run the Java Version

### 1. Compile and Run
```bash
# Create directory structure
mkdir -p MindMapConsole/src/{model,core,util}
mkdir -p MindMapConsole/data

# Copy the code files to appropriate directories
# Then compile
javac -d . src/Main.java src/model/*.java src/core/*.java src/util/*.java

# Run
java Main
```

### 2. Sample Usage
```
=== MindMap Console ===
Welcome to your digital mind mapping tool!

=== Main Menu ===
1. Add Node
2. Link Nodes
3. View Node
4. Search Nodes
5. Explore Map
6. Show Statistics
7. Save Map
8. Load Map
9. Exit
Choose an option: 1

=== Add New Node ===
1. Idea  2. Goal  3. Question  4. Note
Node type: 2
Title: Learn Java Programming
Description: Master Java fundamentals and advanced concepts
Tags (comma-separated): programming, education, java
Node added successfully!
```

## Connecting to GitHub

### 1. Initialize Git Repository
```bash
cd MindMapConsole
git init
```

### 2. Create .gitignore
```
# Compiled class files
*.class

# Log files
*.log

# Package Files
*.jar
*.war
*.nar
*.ear
*.zip
*.tar.gz
*.rar

# IDE files
.vscode/
.idea/
*.iml

# OS files
.DS_Store
Thumbs.db

# Data files (optional - remove if you want to track them)
data/*.txt
```

### 3. Create Repository on GitHub
1. Go to https://github.com
2. Click "New repository"
3. Name it "mindmap-console-java"
4. Don't initialize with README (since you already have code)

### 4. Connect and Push
```bash
git add .
git commit -m "Initial commit: Java MindMap Console implementation"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mindmap-console-java.git
git push -u origin main
```

### 5. Create README.md
```markdown
# MindMap Console - Java Implementation

A console-based mind mapping tool implemented in Java with object-oriented design principles.

## Features
- Create different types of nodes (Ideas, Goals, Questions, Notes)
- Link nodes together to form a network
- Search functionality
- Export/Import mind maps
- Navigation and exploration tools

## Getting Started

### Prerequisites
- Java 8 or higher
- No external dependencies required

### Running the Application
\`\`\`bash
javac -d . src/Main.java src/model/*.java src/core/*.java src/util/*.java
java Main
\`\`\`

## Project Structure
- `model/` - Node classes and data models
- `core/` - Core business logic (MindMap, MapExplorer)
- `util/` - Utility classes (MapStorage)
- `data/` - Saved mind map files

## Usage Examples
[Add screenshots or usage examples here]

## Contributing
Feel free to submit issues and enhancement requests!
```

This gives you the complete Java implementation that matches the functionality of your web application, plus instructions for GitHub integration.