import { pgTable, text, serial, integer, real, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const nodes = pgTable("nodes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type").notNull(), // 'idea' | 'goal' | 'question' | 'note'
  tags: json("tags").$type<string[]>(),
  x: real("x"),
  y: real("y"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const connections = pgTable("connections", {
  id: serial("id").primaryKey(),
  sourceId: integer("source_id").notNull().references(() => nodes.id, { onDelete: 'cascade' }),
  targetId: integer("target_id").notNull().references(() => nodes.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const nodesRelations = relations(nodes, ({ many }) => ({
  sourceConnections: many(connections, { relationName: "sourceNode" }),
  targetConnections: many(connections, { relationName: "targetNode" }),
}));

export const connectionsRelations = relations(connections, ({ one }) => ({
  sourceNode: one(nodes, {
    fields: [connections.sourceId],
    references: [nodes.id],
    relationName: "sourceNode",
  }),
  targetNode: one(nodes, {
    fields: [connections.targetId],
    references: [nodes.id],
    relationName: "targetNode",
  }),
}));

export const insertNodeSchema = createInsertSchema(nodes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertConnectionSchema = createInsertSchema(connections).omit({
  id: true,
  createdAt: true,
});

export const updateNodeSchema = insertNodeSchema.partial().extend({
  id: z.number(),
});

export type InsertNode = z.infer<typeof insertNodeSchema>;
export type InsertConnection = z.infer<typeof insertConnectionSchema>;
export type UpdateNode = z.infer<typeof updateNodeSchema>;
export type Node = typeof nodes.$inferSelect;
export type Connection = typeof connections.$inferSelect;
