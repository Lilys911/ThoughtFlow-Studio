import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertNodeSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

interface CreateNodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const formSchema = insertNodeSchema.extend({
  tags: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function CreateNodeModal({ isOpen, onClose, onSuccess }: CreateNodeModalProps) {
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      type: "idea",
      tags: "",
      x: Math.random() * 400,
      y: Math.random() * 300,
    },
  });

  const createNodeMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const tags = data.tags 
        ? data.tags.split(",").map(tag => tag.trim()).filter(tag => tag.length > 0)
        : [];
      
      const response = await apiRequest("POST", "/api/nodes", {
        ...data,
        tags,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Node created",
        description: "Your new node has been added to the mind map.",
      });
      form.reset();
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Creation failed",
        description: "Failed to create the node. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    createNodeMutation.mutate(data);
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Node</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="type" className="text-sm font-medium text-gray-700">
              Node Type
            </Label>
            <Select value={form.watch("type")} onValueChange={(value) => form.setValue("type", value)}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select node type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="idea">Idea</SelectItem>
                <SelectItem value="goal">Goal</SelectItem>
                <SelectItem value="question">Question</SelectItem>
                <SelectItem value="note">Note</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.type && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.type.message}
              </p>
            )}
          </div>
          
          <div>
            <Label htmlFor="title" className="text-sm font-medium text-gray-700">
              Title
            </Label>
            <Input
              id="title"
              placeholder="Enter node title..."
              {...form.register("title")}
              className="mt-1"
            />
            {form.formState.errors.title && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.title.message}
              </p>
            )}
          </div>
          
          <div>
            <Label htmlFor="description" className="text-sm font-medium text-gray-700">
              Description
            </Label>
            <Textarea
              id="description"
              rows={3}
              placeholder="Describe your idea..."
              {...form.register("description")}
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="tags" className="text-sm font-medium text-gray-700">
              Tags (optional)
            </Label>
            <Input
              id="tags"
              placeholder="Add tags separated by commas"
              {...form.register("tags")}
              className="mt-1"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button 
              type="submit" 
              className="flex-1"
              disabled={createNodeMutation.isPending}
            >
              {createNodeMutation.isPending ? "Creating..." : "Create Node"}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={handleClose}
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
