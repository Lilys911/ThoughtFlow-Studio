import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Node } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, X } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  searchQuery: string;
  onSelectNode: (node: Node) => void;
}

export default function SearchModal({ 
  isOpen, 
  onClose, 
  searchQuery: initialQuery, 
  onSelectNode 
}: SearchModalProps) {
  const [query, setQuery] = useState(initialQuery);
  
  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  const { data: searchResults = [], isLoading } = useQuery<Node[]>({
    queryKey: ["/api/nodes/search", query],
    enabled: query.length > 2,
    queryFn: async () => {
      const response = await fetch(`/api/nodes/search/${encodeURIComponent(query)}`);
      if (!response.ok) {
        throw new Error('Search failed');
      }
      return response.json();
    },
  });

  const nodeTypeColors = {
    idea: "bg-blue-500",
    goal: "bg-amber-500",
    question: "bg-purple-500", 
    note: "bg-green-500",
  };

  const handleSelectNode = (node: Node) => {
    onSelectNode(node);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Search Results</DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="mt-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search nodes by title, description, or tags..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
          </div>
        </DialogHeader>
        
        <div className="max-h-96 overflow-y-auto">
          {query.length <= 2 ? (
            <div className="text-center py-8">
              <Search className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">Type at least 3 characters to search</p>
            </div>
          ) : isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-3"></div>
              <p className="text-gray-600">Searching...</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="text-center py-8">
              <Search className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">No nodes found matching your search</p>
            </div>
          ) : (
            <div className="space-y-3">
              {searchResults.map((node) => (
                <Card 
                  key={node.id}
                  className="border border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors"
                  onClick={() => handleSelectNode(node)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${nodeTypeColors[node.type as keyof typeof nodeTypeColors] || "bg-gray-400"}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-gray-900 truncate">{node.title}</h4>
                          <Badge variant="secondary" className="text-xs capitalize">
                            {node.type}
                          </Badge>
                        </div>
                        {node.description && (
                          <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                            {node.description}
                          </p>
                        )}
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span>
                            {node.updatedAt 
                              ? `Updated ${formatDistanceToNow(new Date(node.updatedAt), { addSuffix: true })}`
                              : "Just created"
                            }
                          </span>
                        </div>
                        {node.tags && node.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {node.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
