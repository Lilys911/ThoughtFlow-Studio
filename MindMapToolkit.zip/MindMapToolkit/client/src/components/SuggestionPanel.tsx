import { useState } from "react";
import { type Node, type Connection } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Target, HelpCircle, StickyNote, Sparkles, ArrowRight, X } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SuggestionPanelProps {
  nodes: Node[];
  connections: Connection[];
  onClose: () => void;
}

interface Suggestion {
  type: 'connection' | 'grouping' | 'insight';
  title: string;
  description: string;
  nodes: Node[];
  action?: string;
}

export default function SuggestionPanel({ nodes, connections, onClose }: SuggestionPanelProps) {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const createConnectionMutation = useMutation({
    mutationFn: async ({ sourceId, targetId }: { sourceId: number; targetId: number }) => {
      return await apiRequest("POST", "/api/connections", { sourceId, targetId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      toast({
        title: "Connection created",
        description: "Suggested connection has been added.",
      });
    },
  });

  const analyzeNodes = () => {
    setIsAnalyzing(true);
    const newSuggestions: Suggestion[] = [];

    // Find unconnected nodes of similar types
    const nodesByType = nodes.reduce((acc, node) => {
      if (!acc[node.type]) acc[node.type] = [];
      acc[node.type].push(node);
      return acc;
    }, {} as Record<string, Node[]>);

    // Suggest connections between similar types
    Object.entries(nodesByType).forEach(([type, typeNodes]) => {
      if (typeNodes.length > 1) {
        for (let i = 0; i < typeNodes.length - 1; i++) {
          for (let j = i + 1; j < typeNodes.length; j++) {
            const node1 = typeNodes[i];
            const node2 = typeNodes[j];
            
            // Check if already connected
            const alreadyConnected = connections.some(conn =>
              (conn.sourceId === node1.id && conn.targetId === node2.id) ||
              (conn.sourceId === node2.id && conn.targetId === node1.id)
            );

            if (!alreadyConnected) {
              // Check for keyword similarity
              const node1Keywords = extractKeywords(node1);
              const node2Keywords = extractKeywords(node2);
              const commonKeywords = node1Keywords.filter(k => node2Keywords.includes(k));

              if (commonKeywords.length > 0) {
                newSuggestions.push({
                  type: 'connection',
                  title: `Connect "${node1.title}" and "${node2.title}"`,
                  description: `Both ${type} nodes share common themes: ${commonKeywords.join(', ')}`,
                  nodes: [node1, node2],
                  action: 'connect'
                });
              }
            }
          }
        }
      }
    });

    // Suggest connecting goals with ideas
    const goals = nodesByType.goal || [];
    const ideas = nodesByType.idea || [];
    
    goals.forEach(goal => {
      ideas.forEach(idea => {
        const alreadyConnected = connections.some(conn =>
          (conn.sourceId === goal.id && conn.targetId === idea.id) ||
          (conn.sourceId === idea.id && conn.targetId === goal.id)
        );

        if (!alreadyConnected) {
          const goalKeywords = extractKeywords(goal);
          const ideaKeywords = extractKeywords(idea);
          const commonKeywords = goalKeywords.filter(k => ideaKeywords.includes(k));

          if (commonKeywords.length > 0) {
            newSuggestions.push({
              type: 'connection',
              title: `Link goal "${goal.title}" with idea "${idea.title}"`,
              description: `This idea could help achieve your goal. Common themes: ${commonKeywords.join(', ')}`,
              nodes: [goal, idea],
              action: 'connect'
            });
          }
        }
      });
    });

    // Suggest grouping nodes with many tags in common
    const tagGroups = findTagGroups(nodes);
    tagGroups.forEach(group => {
      if (group.nodes.length > 2) {
        newSuggestions.push({
          type: 'grouping',
          title: `Group nodes with "${group.tag}" theme`,
          description: `These ${group.nodes.length} nodes all relate to "${group.tag}" and could be organized together`,
          nodes: group.nodes
        });
      }
    });

    // Generate insights about the mind map structure
    if (nodes.length > 5) {
      const insights = generateInsights(nodes, connections);
      newSuggestions.push(...insights);
    }

    setSuggestions(newSuggestions.slice(0, 8)); // Limit to 8 suggestions
    setIsAnalyzing(false);
  };

  const extractKeywords = (node: Node): string[] => {
    const text = `${node.title} ${node.description || ''}`.toLowerCase();
    const words = text.match(/\b\w{3,}\b/g) || [];
    const stopWords = ['the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'had', 'her', 'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'his', 'how', 'its', 'may', 'new', 'now', 'old', 'see', 'two', 'who', 'boy', 'did', 'she', 'use', 'her', 'way', 'oil', 'sit', 'set', 'run', 'eat'];
    return Array.from(new Set(words.filter(word => !stopWords.includes(word) && word.length > 3)));
  };

  const findTagGroups = (nodes: Node[]) => {
    const tagCounts: Record<string, Node[]> = {};
    
    nodes.forEach(node => {
      if (node.tags) {
        node.tags.forEach(tag => {
          if (!tagCounts[tag]) tagCounts[tag] = [];
          tagCounts[tag].push(node);
        });
      }
    });

    return Object.entries(tagCounts)
      .filter(([_, nodes]) => nodes.length > 1)
      .map(([tag, nodes]) => ({ tag, nodes }));
  };

  const generateInsights = (nodes: Node[], connections: Connection[]): Suggestion[] => {
    const insights: Suggestion[] = [];
    
    // Find isolated nodes
    const connectedNodeIds = new Set();
    connections.forEach(conn => {
      connectedNodeIds.add(conn.sourceId);
      connectedNodeIds.add(conn.targetId);
    });
    
    const isolatedNodes = nodes.filter(node => !Array.from(connectedNodeIds).includes(node.id));
    
    if (isolatedNodes.length > 0) {
      insights.push({
        type: 'insight',
        title: `${isolatedNodes.length} isolated nodes found`,
        description: 'These nodes have no connections. Consider linking them to related ideas.',
        nodes: isolatedNodes.slice(0, 3)
      });
    }

    // Check balance of node types
    const typeCount = nodes.reduce((acc, node) => {
      acc[node.type] = (acc[node.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    if (typeCount.idea > typeCount.goal * 3) {
      insights.push({
        type: 'insight',
        title: 'Many ideas, few goals',
        description: 'Consider converting some ideas into actionable goals to maintain focus.',
        nodes: []
      });
    }

    return insights;
  };

  const handleConnectNodes = (node1: Node, node2: Node) => {
    createConnectionMutation.mutate({
      sourceId: node1.id,
      targetId: node2.id
    });
  };

  const nodeTypeConfig = {
    idea: { icon: Lightbulb, color: "bg-blue-500" },
    goal: { icon: Target, color: "bg-amber-500" },
    question: { icon: HelpCircle, color: "bg-purple-500" },
    note: { icon: StickyNote, color: "bg-green-500" },
  };

  return (
    <aside className="w-80 bg-white border-l border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Sparkles className="h-5 w-5 mr-2 text-purple-500" />
            AI Suggestions
          </h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <Button 
          onClick={analyzeNodes} 
          disabled={isAnalyzing || nodes.length === 0}
          className="w-full"
        >
          {isAnalyzing ? "Analyzing..." : "Analyze Mind Map"}
        </Button>
      </div>

      <div className="p-6 overflow-y-auto max-h-[calc(100vh-200px)]">
        {suggestions.length === 0 ? (
          <div className="text-center py-8">
            <Sparkles className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-600 text-sm">
              {nodes.length === 0 
                ? "Create some nodes to get suggestions"
                : "Click 'Analyze Mind Map' to get suggestions"}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {suggestions.map((suggestion, index) => (
              <Card key={index} className="border border-gray-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-900">
                    {suggestion.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-xs text-gray-600 mb-3">{suggestion.description}</p>
                  
                  {suggestion.nodes.length > 0 && (
                    <div className="space-y-2 mb-3">
                      {suggestion.nodes.slice(0, 2).map((node) => {
                        const config = nodeTypeConfig[node.type as keyof typeof nodeTypeConfig];
                        const Icon = config?.icon || Lightbulb;
                        
                        return (
                          <div key={node.id} className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${config?.color || "bg-gray-400"}`} />
                            <span className="text-xs text-gray-700 truncate">{node.title}</span>
                          </div>
                        );
                      })}
                      {suggestion.nodes.length > 2 && (
                        <div className="text-xs text-gray-500">
                          +{suggestion.nodes.length - 2} more nodes
                        </div>
                      )}
                    </div>
                  )}

                  {suggestion.action === 'connect' && suggestion.nodes.length === 2 && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleConnectNodes(suggestion.nodes[0], suggestion.nodes[1])}
                      disabled={createConnectionMutation.isPending}
                      className="w-full text-xs"
                    >
                      <ArrowRight className="h-3 w-3 mr-1" />
                      Connect Nodes
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
}