import { useState } from "react";
import { type Node } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, X, Link } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AddConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceNode: Node;
  availableNodes: Node[];
}

export default function AddConnectionModal({
  isOpen,
  onClose,
  sourceNode,
  availableNodes,
}: AddConnectionModalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const filteredNodes = availableNodes.filter(node => {
    if (node.id === sourceNode.id) return false;
    if (!searchQuery) return true;
    
    const searchTerm = searchQuery.toLowerCase();
    return (
      node.title.toLowerCase().includes(searchTerm) ||
      (node.description && node.description.toLowerCase().includes(searchTerm)) ||
      (node.tags && node.tags.some(tag => tag.toLowerCase().includes(searchTerm)))
    );
  });

  const createConnectionMutation = useMutation({
    mutationFn: async (targetNodeId: number) => {
      return await apiRequest("POST", "/api/connections", {
        sourceId: sourceNode.id,
        targetId: targetNodeId,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      toast({
        title: "Connection created",
        description: "Nodes have been connected successfully.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Connection failed",
        description: "Failed to create connection between nodes.",
        variant: "destructive",
      });
    },
  });

  const handleConnect = (targetNode: Node) => {
    createConnectionMutation.mutate(targetNode.id);
  };

  const nodeTypeColors = {
    idea: "bg-blue-500",
    goal: "bg-amber-500",
    question: "bg-purple-500",
    note: "bg-green-500",
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Connect "{sourceNode.title}" to...</DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="mt-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search nodes to connect..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
          </div>
        </DialogHeader>

        <div className="max-h-96 overflow-y-auto">
          {filteredNodes.length === 0 ? (
            <div className="text-center py-8">
              <Link className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">No nodes available to connect</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredNodes.map((node) => (
                <Card
                  key={node.id}
                  className="border border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors"
                  onClick={() => handleConnect(node)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1">
                        <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${nodeTypeColors[node.type as keyof typeof nodeTypeColors] || "bg-gray-400"}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="font-medium text-gray-900 truncate">{node.title}</h4>
                            <Badge variant="secondary" className="text-xs capitalize">
                              {node.type}
                            </Badge>
                          </div>
                          {node.description && (
                            <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                              {node.description}
                            </p>
                          )}
                          {node.tags && node.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {node.tags.slice(0, 3).map((tag, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                              {node.tags.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{node.tags.length - 3}
                                </Badge>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="ml-4"
                        disabled={createConnectionMutation.isPending}
                      >
                        <Link className="h-3 w-3 mr-1" />
                        Connect
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}