interface LogoProps {
  className?: string;
  size?: number;
}

export default function Logo({ className = "", size = 32 }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background circle */}
      <circle
        cx="16"
        cy="16"
        r="14"
        fill="url(#gradient)"
        stroke="#3B82F6"
        strokeWidth="1"
      />
      
      {/* Central node */}
      <circle
        cx="16"
        cy="16"
        r="3"
        fill="#1E40AF"
      />
      
      {/* Flowing connections */}
      <path
        d="M16 13 C18 11, 22 11, 24 13"
        stroke="#3B82F6"
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />
      
      <path
        d="M19 16 C21 18, 21 22, 19 24"
        stroke="#3B82F6"
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />
      
      <path
        d="M16 19 C14 21, 10 21, 8 19"
        stroke="#3B82F6"
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />
      
      <path
        d="M13 16 C11 14, 11 10, 13 8"
        stroke="#3B82F6"
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />
      
      {/* Outer nodes */}
      <circle cx="24" cy="13" r="2" fill="#60A5FA" />
      <circle cx="19" cy="24" r="2" fill="#60A5FA" />
      <circle cx="8" cy="19" r="2" fill="#60A5FA" />
      <circle cx="13" cy="8" r="2" fill="#60A5FA" />
      
      {/* Thought bubbles */}
      <circle cx="26" cy="9" r="1" fill="#93C5FD" opacity="0.7" />
      <circle cx="23" cy="26" r="1" fill="#93C5FD" opacity="0.7" />
      <circle cx="6" cy="23" r="1" fill="#93C5FD" opacity="0.7" />
      <circle cx="9" cy="6" r="1" fill="#93C5FD" opacity="0.7" />
      
      {/* Gradient definition */}
      <defs>
        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#DBEAFE", stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: "#BFDBFE", stopOpacity: 1 }} />
        </linearGradient>
      </defs>
    </svg>
  );
}