import { type Node, type Connection } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, X, Brain, Link, BarChart3 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  nodes: Node[];
  connections: Connection[];
}

export default function ProfileModal({ isOpen, onClose, nodes, connections }: ProfileModalProps) {
  const nodesByType = nodes.reduce((acc, node) => {
    acc[node.type] = (acc[node.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const mostRecentNode = nodes
    .sort((a, b) => new Date(b.updatedAt || 0).getTime() - new Date(a.updatedAt || 0).getTime())[0];

  const totalTags = nodes.reduce((acc, node) => {
    return acc + (node.tags?.length || 0);
  }, 0);

  const avgConnectionsPerNode = nodes.length > 0 ? (connections.length * 2) / nodes.length : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center">
              <User className="h-5 w-5 mr-2" />
              Profile
            </DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          {/* User Info */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-3">
                  <User className="h-5 w-5 text-white" />
                </div>
                lily_collins
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="font-medium text-gray-900">Total Nodes</div>
                  <div className="text-2xl font-bold text-primary">{nodes.length}</div>
                </div>
                <div>
                  <div className="font-medium text-gray-900">Connections</div>
                  <div className="text-2xl font-bold text-primary">{connections.length}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Node Statistics */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center">
                <Brain className="h-4 w-4 mr-2" />
                Node Types
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {Object.entries(nodesByType).map(([type, count]) => (
                  <div key={type} className="flex items-center justify-between">
                    <Badge variant="secondary" className="capitalize">
                      {type}
                    </Badge>
                    <span className="font-medium">{count}</span>
                  </div>
                ))}
                {Object.keys(nodesByType).length === 0 && (
                  <div className="text-sm text-gray-500 text-center py-2">
                    No nodes created yet
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Activity Stats */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center">
                <BarChart3 className="h-4 w-4 mr-2" />
                Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Tags</span>
                  <span className="font-medium">{totalTags}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Avg Connections</span>
                  <span className="font-medium">{avgConnectionsPerNode.toFixed(1)}</span>
                </div>
                {mostRecentNode && (
                  <div>
                    <div className="text-gray-600 mb-1">Last Activity</div>
                    <div className="font-medium truncate">{mostRecentNode.title}</div>
                    <div className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(mostRecentNode.updatedAt || 0), { addSuffix: true })}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}