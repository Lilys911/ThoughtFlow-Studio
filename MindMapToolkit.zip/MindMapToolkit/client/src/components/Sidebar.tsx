import { type Node } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, Target, HelpCircle, StickyNote, Download, Upload, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface SidebarProps {
  nodes: Node[];
  onCreateNode: () => void;
}

const nodeTypeButtons = [
  { type: "idea", icon: Lightbulb, label: "Idea", color: "hover:border-primary hover:bg-blue-50 hover:text-primary" },
  { type: "goal", icon: Target, label: "Goal", color: "hover:border-amber-500 hover:bg-amber-50 hover:text-amber-600" },
  { type: "question", icon: HelpCircle, label: "Question", color: "hover:border-purple-500 hover:bg-purple-50 hover:text-purple-600" },
  { type: "note", icon: StickyNote, label: "Note", color: "hover:border-green-500 hover:bg-green-50 hover:text-green-600" },
];

const nodeTypeColors = {
  idea: "bg-blue-500",
  goal: "bg-amber-500",
  question: "bg-purple-500",
  note: "bg-green-500",
};

export default function Sidebar({ nodes, onCreateNode }: SidebarProps) {
  const recentNodes = nodes
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5);

  const handleExport = () => {
    const dataStr = JSON.stringify({ nodes, timestamp: new Date().toISOString() }, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mindmap-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <aside className="w-80 bg-white border-r border-gray-200 flex flex-col">
      {/* Node Types */}
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-sm font-medium text-gray-900 mb-4">Add New Node</h3>
        <div className="grid grid-cols-2 gap-3">
          {nodeTypeButtons.map(({ type, icon: Icon, label, color }) => (
            <Button
              key={type}
              variant="outline"
              className={`p-3 h-auto border-2 border-dashed border-gray-300 hover:border-solid transition-all group ${color}`}
              onClick={onCreateNode}
            >
              <div className="flex flex-col items-center space-y-1">
                <Icon className="h-5 w-5 text-gray-400 group-hover:text-current" />
                <span className="text-sm font-medium text-gray-700 group-hover:text-current">{label}</span>
              </div>
            </Button>
          ))}
        </div>
      </div>

      {/* Recent Nodes */}
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-sm font-medium text-gray-900 mb-4">Recent Nodes</h3>
        <div className="space-y-2">
          {recentNodes.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">No nodes created yet</p>
          ) : (
            recentNodes.map((node) => (
              <Card key={node.id} className="border border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors">
                <CardContent className="p-3">
                  <div className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full ${nodeTypeColors[node.type as keyof typeof nodeTypeColors] || "bg-gray-400"}`} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-gray-900 truncate">{node.title}</div>
                      <div className="text-xs text-gray-500">
                        {node.updatedAt ? formatDistanceToNow(new Date(node.updatedAt), { addSuffix: true }) : "Just now"}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Map Actions */}
      <div className="p-6 flex-1">
        <h3 className="text-sm font-medium text-gray-900 mb-4">Map Actions</h3>
        <div className="space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={handleExport}
          >
            <Download className="w-4 h-4 mr-3 text-gray-400" />
            <span className="text-sm text-gray-700">Export Map</span>
          </Button>
          
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = '.json';
              input.onchange = (e) => {
                const file = (e.target as HTMLInputElement).files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onload = (e) => {
                    try {
                      const data = JSON.parse(e.target?.result as string);
                      console.log('Import data:', data);
                      // TODO: Implement import functionality
                    } catch (error) {
                      console.error('Failed to parse import file:', error);
                    }
                  };
                  reader.readAsText(file);
                }
              };
              input.click();
            }}
          >
            <Upload className="w-4 h-4 mr-3 text-gray-400" />
            <span className="text-sm text-gray-700">Load Map</span>
          </Button>
          
          <Button
            variant="ghost"
            className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={() => {
              if (confirm('Are you sure you want to clear the entire map? This cannot be undone.')) {
                // TODO: Implement clear map functionality
                console.log('Clear map');
              }
            }}
          >
            <Trash2 className="w-4 h-4 mr-3" />
            <span className="text-sm">Clear Map</span>
          </Button>
        </div>
      </div>
    </aside>
  );
}
