import { useCallback, useState, useRef, useEffect } from "react";
import ReactFlow, {
  Node as FlowNode,
  Edge,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  EdgeChange,
  NodeChange,
  MarkerType,
  Panel,
} from "reactflow";
import "reactflow/dist/style.css";
import { type Node, type Connection as ConnectionType } from "@shared/schema";
import NodeCard from "./NodeCard";
import { ZoomIn, ZoomOut, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const nodeTypes = {
  mindMapNode: NodeCard,
};

interface MindMapCanvasProps {
  nodes: Node[];
  connections: ConnectionType[];
  selectedNode: Node | null;
  onSelectNode: (node: Node | null) => void;
}

export default function MindMapCanvas({ 
  nodes, 
  connections, 
  selectedNode, 
  onSelectNode 
}: MindMapCanvasProps) {
  const { toast } = useToast();
  const reactFlowInstance = useRef<any>(null);

  // Convert our nodes to ReactFlow format
  const flowNodes: FlowNode[] = nodes.map((node) => ({
    id: node.id.toString(),
    type: "mindMapNode",
    position: { x: node.x || 0, y: node.y || 0 },
    data: { 
      node,
      isSelected: selectedNode?.id === node.id,
      onSelect: () => onSelectNode(node),
    },
  }));

  // Convert our connections to ReactFlow edges
  const flowEdges: Edge[] = connections.map((connection) => ({
    id: connection.id.toString(),
    source: connection.sourceId.toString(),
    target: connection.targetId.toString(),
    type: "default",
    style: { stroke: "#2563EB", strokeWidth: 2, strokeDasharray: "5,5" },
    markerEnd: {
      type: MarkerType.ArrowClosed,
      color: "#2563EB",
    },
  }));

  const [rfNodes, setNodes, onNodesChange] = useNodesState(flowNodes);
  const [rfEdges, setEdges, onEdgesChange] = useEdgesState(flowEdges);

  // Update ReactFlow nodes when our data changes
  useEffect(() => {
    setNodes(flowNodes);
  }, [nodes, selectedNode, setNodes]);

  // Update ReactFlow edges when connections change
  useEffect(() => {
    setEdges(flowEdges);
  }, [connections, setEdges]);

  // Handle node position changes
  const updateNodeMutation = useMutation({
    mutationFn: async ({ id, x, y }: { id: number; x: number; y: number }) => {
      return await apiRequest("PUT", `/api/nodes/${id}`, { x, y });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/nodes"] });
    },
  });

  // Handle creating new connections
  const createConnectionMutation = useMutation({
    mutationFn: async ({ sourceId, targetId }: { sourceId: number; targetId: number }) => {
      return await apiRequest("POST", "/api/connections", { sourceId, targetId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      toast({
        title: "Connection created",
        description: "Nodes have been connected successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Connection failed",
        description: "Failed to create connection between nodes.",
        variant: "destructive",
      });
    },
  });

  const onNodeDragStop = useCallback((event: any, node: FlowNode) => {
    const nodeId = parseInt(node.id);
    updateNodeMutation.mutate({
      id: nodeId,
      x: node.position.x,
      y: node.position.y,
    });
  }, [updateNodeMutation]);

  const onConnect = useCallback((params: Connection) => {
    if (params.source && params.target) {
      const sourceId = parseInt(params.source);
      const targetId = parseInt(params.target);
      createConnectionMutation.mutate({ sourceId, targetId });
    }
  }, [createConnectionMutation]);

  const onPaneClick = useCallback(() => {
    onSelectNode(null);
  }, [onSelectNode]);

  const handleZoomIn = () => {
    reactFlowInstance.current?.zoomIn();
  };

  const handleZoomOut = () => {
    reactFlowInstance.current?.zoomOut();
  };

  const handleFitView = () => {
    reactFlowInstance.current?.fitView();
  };

  if (nodes.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="text-6xl text-gray-300 mb-4">🧠</div>
          <h3 className="text-xl font-medium text-gray-900 mb-2">Start Building Your Mind Map</h3>
          <p className="text-gray-600">Create your first node to begin organizing your ideas</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full w-full">
      <ReactFlow
        nodes={rfNodes}
        edges={rfEdges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeDragStop={onNodeDragStop}
        onPaneClick={onPaneClick}
        nodeTypes={nodeTypes}
        fitView
        onInit={(instance) => {
          reactFlowInstance.current = instance;
        }}
        className="bg-gray-50"
      >
        <Background color="#e5e7eb" gap={20} />
        <Controls showInteractive={false} />
        <Panel position="top-right" className="flex space-x-2">
          <Button
            size="sm"
            variant="outline"
            onClick={handleZoomIn}
            className="w-10 h-10 p-0"
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleZoomOut}
            className="w-10 h-10 p-0"
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleFitView}
            className="w-10 h-10 p-0"
          >
            <Home className="h-4 w-4" />
          </Button>
        </Panel>
      </ReactFlow>
    </div>
  );
}
