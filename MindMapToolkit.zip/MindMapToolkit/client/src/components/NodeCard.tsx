import { Handle, Position } from "reactflow";
import { type Node } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, Target, HelpCircle, StickyNote, Edit } from "lucide-react";

interface NodeCardProps {
  data: {
    node: Node;
    isSelected: boolean;
    onSelect: () => void;
  };
}

const nodeTypeConfig = {
  idea: {
    icon: Lightbulb,
    color: "bg-blue-500",
    bgColor: "bg-blue-50",
    textColor: "text-blue-700",
    borderColor: "border-blue-200",
  },
  goal: {
    icon: Target,
    color: "bg-amber-500",
    bgColor: "bg-amber-50",
    textColor: "text-amber-700",
    borderColor: "border-amber-200",
  },
  question: {
    icon: HelpCircle,
    color: "bg-purple-500",
    bgColor: "bg-purple-50",
    textColor: "text-purple-700",
    borderColor: "border-purple-200",
  },
  note: {
    icon: StickyNote,
    color: "bg-green-500",
    bgColor: "bg-green-50",
    textColor: "text-green-700",
    borderColor: "border-green-200",
  },
};

export default function NodeCard({ data }: NodeCardProps) {
  const { node, isSelected, onSelect } = data;
  const config = nodeTypeConfig[node.type as keyof typeof nodeTypeConfig] || nodeTypeConfig.idea;
  const Icon = config.icon;

  return (
    <div className="relative">
      <Handle
        type="target"
        position={Position.Top}
        style={{ background: "#2563EB", width: 8, height: 8 }}
      />
      <Handle
        type="source"
        position={Position.Bottom}
        style={{ background: "#2563EB", width: 8, height: 8 }}
      />
      <Handle
        type="target"
        position={Position.Left}
        style={{ background: "#2563EB", width: 8, height: 8 }}
      />
      <Handle
        type="source"
        position={Position.Right}
        style={{ background: "#2563EB", width: 8, height: 8 }}
      />
      
      <Card 
        className={`min-w-48 max-w-64 cursor-pointer transition-all duration-200 hover:shadow-lg ${
          isSelected 
            ? "ring-2 ring-primary shadow-lg" 
            : "shadow-md"
        } ${config.borderColor} border-2`}
        onClick={onSelect}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <div className={`w-6 h-6 rounded-full ${config.color} flex items-center justify-center`}>
                <Icon className="w-3 h-3 text-white" />
              </div>
              <Badge variant="secondary" className={`${config.bgColor} ${config.textColor} text-xs font-medium uppercase tracking-wide`}>
                {node.type}
              </Badge>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="w-6 h-6 p-0 hover:bg-gray-100"
              onClick={(e) => {
                e.stopPropagation();
                onSelect();
              }}
            >
              <Edit className="w-3 h-3 text-gray-400" />
            </Button>
          </div>
          
          <h4 className="font-semibold text-gray-900 mb-1 line-clamp-2">
            {node.title}
          </h4>
          
          {node.description && (
            <p className="text-sm text-gray-600 line-clamp-2 mb-2">
              {node.description}
            </p>
          )}
          
          {node.tags && node.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {node.tags.slice(0, 3).map((tag, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
              {node.tags.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{node.tags.length - 3}
                </Badge>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
