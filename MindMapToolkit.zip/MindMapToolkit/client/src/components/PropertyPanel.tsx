import { useState, useEffect } from "react";
import { type Node, type Connection } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { X, Trash2, Unlink, Plus } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { updateNodeSchema } from "@shared/schema";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { z } from "zod";
import AddConnectionModal from "./AddConnectionModal";

interface PropertyPanelProps {
  node: Node;
  nodes: Node[];
  connections: Connection[];
  onClose: () => void;
  onUpdateNode: (node: Node) => void;
}

const formSchema = updateNodeSchema.extend({
  tags: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function PropertyPanel({ 
  node, 
  nodes, 
  connections, 
  onClose, 
  onUpdateNode 
}: PropertyPanelProps) {
  const { toast } = useToast();
  const [isAddConnectionModalOpen, setIsAddConnectionModalOpen] = useState(false);
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      id: node.id,
      title: node.title,
      description: node.description || "",
      type: node.type,
      tags: node.tags?.join(", ") || "",
    },
  });

  const nodeConnections = connections.filter(
    conn => conn.sourceId === node.id || conn.targetId === node.id
  );

  const connectedNodes = nodeConnections.map(conn => {
    const connectedNodeId = conn.sourceId === node.id ? conn.targetId : conn.sourceId;
    return {
      connection: conn,
      node: nodes.find(n => n.id === connectedNodeId),
    };
  }).filter(item => item.node);

  // Update form when node changes
  useEffect(() => {
    form.reset({
      id: node.id,
      title: node.title,
      description: node.description || "",
      type: node.type,
      tags: node.tags?.join(", ") || "",
    });
  }, [node, form]);

  const updateNodeMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const tags = data.tags 
        ? data.tags.split(",").map(tag => tag.trim()).filter(tag => tag.length > 0)
        : [];
      
      const response = await apiRequest("PUT", `/api/nodes/${data.id}`, {
        ...data,
        tags,
      });
      return response.json();
    },
    onSuccess: (updatedNode) => {
      queryClient.invalidateQueries({ queryKey: ["/api/nodes"] });
      onUpdateNode(updatedNode);
      toast({
        title: "Node updated",
        description: "Your changes have been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Failed to update the node. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteNodeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/nodes/${node.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/nodes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      onClose();
      toast({
        title: "Node deleted",
        description: "The node has been removed from your mind map.",
      });
    },
    onError: () => {
      toast({
        title: "Delete failed",
        description: "Failed to delete the node. Please try again.",
        variant: "destructive",
      });
    },
  });

  const removeConnectionMutation = useMutation({
    mutationFn: async (connectionId: number) => {
      await apiRequest("DELETE", `/api/connections/${connectionId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      toast({
        title: "Connection removed",
        description: "The connection has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to remove connection",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    updateNodeMutation.mutate(data);
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this node? This action cannot be undone.")) {
      deleteNodeMutation.mutate();
    }
  };

  const nodeTypeColors = {
    idea: "bg-blue-500",
    goal: "bg-amber-500", 
    question: "bg-purple-500",
    note: "bg-green-500",
  };

  return (
    <aside className="w-80 bg-white border-l border-gray-200">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Node Details</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Node Type Badge */}
        <div className="flex items-center space-x-2 mb-4">
          <div className={`w-4 h-4 rounded-full ${nodeTypeColors[node.type as keyof typeof nodeTypeColors] || "bg-gray-400"}`} />
          <Badge variant="secondary" className="text-sm font-medium uppercase tracking-wide">
            {node.type} Node
          </Badge>
        </div>

        {/* Edit Form */}
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="title" className="text-sm font-medium text-gray-700">
              Title
            </Label>
            <Input
              id="title"
              {...form.register("title")}
              className="mt-1"
            />
            {form.formState.errors.title && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.title.message}
              </p>
            )}
          </div>
          
          <div>
            <Label htmlFor="description" className="text-sm font-medium text-gray-700">
              Description
            </Label>
            <Textarea
              id="description"
              rows={3}
              {...form.register("description")}
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="tags" className="text-sm font-medium text-gray-700">
              Tags
            </Label>
            <Input
              id="tags"
              {...form.register("tags")}
              placeholder="Add tags separated by commas"
              className="mt-1"
            />
          </div>

          <div className="flex space-x-3">
            <Button 
              type="submit" 
              className="flex-1"
              disabled={updateNodeMutation.isPending}
            >
              {updateNodeMutation.isPending ? "Updating..." : "Update Node"}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              size="sm"
              onClick={handleDelete}
              disabled={deleteNodeMutation.isPending}
            >
              <Trash2 className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        </form>
      </div>

      {/* Connections */}
      <div className="p-6 border-b border-gray-200">
        <h4 className="text-sm font-medium text-gray-900 mb-4">
          Connections ({connectedNodes.length})
        </h4>
        <div className="space-y-2">
          {connectedNodes.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">No connections yet</p>
          ) : (
            connectedNodes.map(({ connection, node: connectedNode }) => (
              <Card key={connection.id} className="border border-gray-200 hover:bg-gray-50">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      <div className={`w-2 h-2 rounded-full ${nodeTypeColors[connectedNode!.type as keyof typeof nodeTypeColors] || "bg-gray-400"}`} />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-gray-900 truncate">
                          {connectedNode!.title}
                        </div>
                        <div className="text-xs text-gray-500 capitalize">
                          {connectedNode!.type} Node
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeConnectionMutation.mutate(connection.id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Unlink className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        <Button
          variant="outline"
          className="w-full mt-4 border-2 border-dashed border-gray-300 hover:border-primary hover:bg-blue-50 text-gray-600 hover:text-primary"
          onClick={() => setIsAddConnectionModalOpen(true)}
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Connection
        </Button>
      </div>

      {/* Node History */}
      <div className="p-6">
        <h4 className="text-sm font-medium text-gray-900 mb-4">Recent Activity</h4>
        <div className="space-y-3">
          <div className="text-sm text-gray-600">
            <div className="font-medium">Node created</div>
            <div className="text-xs text-gray-500">
              {node.createdAt ? formatDistanceToNow(new Date(node.createdAt), { addSuffix: true }) : "Unknown"}
            </div>
          </div>
          {node.updatedAt && node.updatedAt !== node.createdAt && (
            <div className="text-sm text-gray-600">
              <div className="font-medium">Last updated</div>
              <div className="text-xs text-gray-500">
                {formatDistanceToNow(new Date(node.updatedAt), { addSuffix: true })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add Connection Modal */}
      <AddConnectionModal
        isOpen={isAddConnectionModalOpen}
        onClose={() => setIsAddConnectionModalOpen(false)}
        sourceNode={node}
        availableNodes={nodes}
      />
    </aside>
  );
}
