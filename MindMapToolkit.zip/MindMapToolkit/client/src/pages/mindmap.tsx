import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Node, type Connection } from "@shared/schema";
import MindMapCanvas from "@/components/MindMapCanvas";
import Sidebar from "@/components/Sidebar";
import PropertyPanel from "@/components/PropertyPanel";
import CreateNodeModal from "@/components/CreateNodeModal";
import SearchModal from "@/components/SearchModal";
import SuggestionPanel from "@/components/SuggestionPanel";
import ProfileModal from "@/components/ProfileModal";
import Logo from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Save, User, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function MindMapPage() {
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isSuggestionPanelOpen, setIsSuggestionPanelOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: nodes = [], isLoading: nodesLoading } = useQuery<Node[]>({
    queryKey: ["/api/nodes"],
  });

  const { data: connections = [], isLoading: connectionsLoading } = useQuery<Connection[]>({
    queryKey: ["/api/connections"],
  });

  const handleSave = async () => {
    try {
      toast({
        title: "Mind map saved",
        description: "Your mind map has been saved successfully.",
      });
    } catch (error) {
      toast({
        title: "Save failed",
        description: "Failed to save your mind map. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.length > 2) {
      setIsSearchModalOpen(true);
    }
  };

  const isLoading = nodesLoading || connectionsLoading;

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Logo size={40} className="flex-shrink-0" />
            <div>
              <h1 className="text-xl font-semibold text-gray-900">ThoughtFlow Studio</h1>
              <div className="text-sm text-gray-500">
                lily_collins's Workspace
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Search Bar */}
            <div className="relative">
              <Input
                type="text"
                placeholder="Search nodes..."
                className="w-64 pl-10"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
            
            {/* Actions */}
            <Button 
              onClick={() => setIsSuggestionPanelOpen(true)} 
              variant="outline"
              className="mr-2"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Suggestions
            </Button>
            
            <Button onClick={handleSave} className="bg-primary hover:bg-blue-600">
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            
            <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors cursor-pointer"
                 onClick={() => setIsProfileModalOpen(true)}>
              <User className="w-4 h-4" />
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar 
          nodes={nodes}
          onCreateNode={() => setIsCreateModalOpen(true)}
        />

        {/* Main Canvas */}
        <div className="flex-1 relative">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-gray-600">Loading your mind map...</p>
              </div>
            </div>
          ) : (
            <MindMapCanvas
              nodes={nodes}
              connections={connections}
              selectedNode={selectedNode}
              onSelectNode={setSelectedNode}
            />
          )}
        </div>

        {/* Property Panel */}
        {selectedNode && (
          <PropertyPanel
            node={selectedNode}
            nodes={nodes}
            connections={connections}
            onClose={() => setSelectedNode(null)}
            onUpdateNode={(updatedNode) => {
              setSelectedNode(updatedNode);
              queryClient.invalidateQueries({ queryKey: ["/api/nodes"] });
            }}
          />
        )}

        {/* Suggestion Panel */}
        {isSuggestionPanelOpen && (
          <SuggestionPanel
            nodes={nodes}
            connections={connections}
            onClose={() => setIsSuggestionPanelOpen(false)}
          />
        )}
      </div>

      {/* Modals */}
      <CreateNodeModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSuccess={() => {
          setIsCreateModalOpen(false);
          queryClient.invalidateQueries({ queryKey: ["/api/nodes"] });
        }}
      />

      <SearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        searchQuery={searchQuery}
        onSelectNode={(node) => {
          setSelectedNode(node);
          setIsSearchModalOpen(false);
        }}
      />

      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        nodes={nodes}
        connections={connections}
      />
    </div>
  );
}
