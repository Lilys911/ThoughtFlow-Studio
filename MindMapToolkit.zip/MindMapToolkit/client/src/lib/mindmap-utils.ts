import { type Node, type Connection } from "@shared/schema";

export interface MindMapData {
  nodes: Node[];
  connections: Connection[];
  metadata: {
    version: string;
    createdAt: string;
    exportedAt: string;
  };
}

export function exportMindMap(nodes: Node[], connections: Connection[]): string {
  const data: MindMapData = {
    nodes,
    connections,
    metadata: {
      version: "1.0",
      createdAt: new Date().toISOString(),
      exportedAt: new Date().toISOString(),
    },
  };
  
  return JSON.stringify(data, null, 2);
}

export function validateMindMapData(data: any): data is MindMapData {
  return (
    data &&
    typeof data === "object" &&
    Array.isArray(data.nodes) &&
    Array.isArray(data.connections) &&
    data.metadata &&
    typeof data.metadata === "object"
  );
}

export function calculateNodePosition(existingNodes: Node[]): { x: number; y: number } {
  if (existingNodes.length === 0) {
    return { x: 400, y: 300 }; // Center position for first node
  }

  // Calculate a position that doesn't overlap with existing nodes
  const padding = 200;
  const maxAttempts = 50;
  
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const x = Math.random() * 800 + 100;
    const y = Math.random() * 600 + 100;
    
    const tooClose = existingNodes.some(node => {
      const distance = Math.sqrt(
        Math.pow((node.x || 0) - x, 2) + Math.pow((node.y || 0) - y, 2)
      );
      return distance < padding;
    });
    
    if (!tooClose) {
      return { x, y };
    }
  }
  
  // Fallback to a grid position if we can't find a good spot
  const gridSize = Math.ceil(Math.sqrt(existingNodes.length + 1));
  const cellSize = 250;
  const row = Math.floor(existingNodes.length / gridSize);
  const col = existingNodes.length % gridSize;
  
  return {
    x: col * cellSize + 100,
    y: row * cellSize + 100,
  };
}

export function getConnectedNodeIds(nodeId: number, connections: Connection[]): number[] {
  return connections
    .filter(conn => conn.sourceId === nodeId || conn.targetId === nodeId)
    .map(conn => conn.sourceId === nodeId ? conn.targetId : conn.sourceId);
}

export function findShortestPath(
  startNodeId: number,
  endNodeId: number,
  connections: Connection[]
): number[] | null {
  if (startNodeId === endNodeId) return [startNodeId];

  const visited = new Set<number>();
  const queue: { nodeId: number; path: number[] }[] = [
    { nodeId: startNodeId, path: [startNodeId] },
  ];

  while (queue.length > 0) {
    const { nodeId, path } = queue.shift()!;

    if (visited.has(nodeId)) continue;
    visited.add(nodeId);

    const connectedIds = getConnectedNodeIds(nodeId, connections);

    for (const connectedId of connectedIds) {
      if (connectedId === endNodeId) {
        return [...path, connectedId];
      }

      if (!visited.has(connectedId)) {
        queue.push({
          nodeId: connectedId,
          path: [...path, connectedId],
        });
      }
    }
  }

  return null; // No path found
}

export function getNodesByType(nodes: Node[], type: string): Node[] {
  return nodes.filter(node => node.type === type);
}

export function searchNodes(nodes: Node[], query: string): Node[] {
  const searchTerm = query.toLowerCase();
  return nodes.filter(node =>
    node.title.toLowerCase().includes(searchTerm) ||
    node.description.toLowerCase().includes(searchTerm) ||
    (node.tags && node.tags.some(tag => tag.toLowerCase().includes(searchTerm)))
  );
}

export function getNodeStatistics(nodes: Node[], connections: Connection[]) {
  const nodesByType = {
    idea: getNodesByType(nodes, "idea").length,
    goal: getNodesByType(nodes, "goal").length,
    question: getNodesByType(nodes, "question").length,
    note: getNodesByType(nodes, "note").length,
  };

  const connectionCounts = nodes.map(node => {
    const count = getConnectedNodeIds(node.id, connections).length;
    return { nodeId: node.id, connectionCount: count };
  });

  const mostConnectedNode = connectionCounts.reduce(
    (max, current) => (current.connectionCount > max.connectionCount ? current : max),
    { nodeId: 0, connectionCount: 0 }
  );

  const averageConnections = connectionCounts.length > 0
    ? connectionCounts.reduce((sum, node) => sum + node.connectionCount, 0) / connectionCounts.length
    : 0;

  return {
    totalNodes: nodes.length,
    totalConnections: connections.length,
    nodesByType,
    mostConnectedNodeId: mostConnectedNode.nodeId,
    averageConnections: Math.round(averageConnections * 100) / 100,
  };
}
