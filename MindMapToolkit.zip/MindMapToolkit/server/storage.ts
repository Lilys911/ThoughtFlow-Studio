import { nodes, connections, type Node, type Connection, type InsertNode, type InsertConnection, type UpdateNode } from "@shared/schema";
import { db } from "./db";
import { eq, or, and, ilike } from "drizzle-orm";

export interface IStorage {
  // Node operations
  getNodes(): Promise<Node[]>;
  getNode(id: number): Promise<Node | undefined>;
  createNode(node: InsertNode): Promise<Node>;
  updateNode(node: UpdateNode): Promise<Node | undefined>;
  deleteNode(id: number): Promise<boolean>;
  searchNodes(query: string): Promise<Node[]>;
  
  // Connection operations
  getConnections(): Promise<Connection[]>;
  getNodeConnections(nodeId: number): Promise<Connection[]>;
  createConnection(connection: InsertConnection): Promise<Connection>;
  deleteConnection(id: number): Promise<boolean>;
  deleteConnectionBetweenNodes(sourceId: number, targetId: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getNodes(): Promise<Node[]> {
    return await db.select().from(nodes);
  }

  async getNode(id: number): Promise<Node | undefined> {
    const [node] = await db.select().from(nodes).where(eq(nodes.id, id));
    return node || undefined;
  }

  async createNode(insertNode: InsertNode): Promise<Node> {
    const [node] = await db
      .insert(nodes)
      .values({
        title: insertNode.title,
        description: insertNode.description,
        type: insertNode.type,
        tags: insertNode.tags,
        x: insertNode.x,
        y: insertNode.y,
      })
      .returning();
    return node;
  }

  async updateNode(updateNode: UpdateNode): Promise<Node | undefined> {
    const updateData: any = { updatedAt: new Date() };
    if (updateNode.title !== undefined) updateData.title = updateNode.title;
    if (updateNode.description !== undefined) updateData.description = updateNode.description;
    if (updateNode.type !== undefined) updateData.type = updateNode.type;
    if (updateNode.tags !== undefined) updateData.tags = updateNode.tags;
    if (updateNode.x !== undefined) updateData.x = updateNode.x;
    if (updateNode.y !== undefined) updateData.y = updateNode.y;

    const [node] = await db
      .update(nodes)
      .set(updateData)
      .where(eq(nodes.id, updateNode.id))
      .returning();
    return node || undefined;
  }

  async deleteNode(id: number): Promise<boolean> {
    const result = await db.delete(nodes).where(eq(nodes.id, id));
    return (result.rowCount || 0) > 0;
  }

  async searchNodes(query: string): Promise<Node[]> {
    const searchTerm = `%${query}%`;
    return await db
      .select()
      .from(nodes)
      .where(
        or(
          ilike(nodes.title, searchTerm),
          ilike(nodes.description, searchTerm)
        )
      );
  }

  async getConnections(): Promise<Connection[]> {
    return await db.select().from(connections);
  }

  async getNodeConnections(nodeId: number): Promise<Connection[]> {
    return await db
      .select()
      .from(connections)
      .where(
        or(
          eq(connections.sourceId, nodeId),
          eq(connections.targetId, nodeId)
        )
      );
  }

  async createConnection(insertConnection: InsertConnection): Promise<Connection> {
    const [connection] = await db
      .insert(connections)
      .values(insertConnection)
      .returning();
    return connection;
  }

  async deleteConnection(id: number): Promise<boolean> {
    const result = await db.delete(connections).where(eq(connections.id, id));
    return (result.rowCount || 0) > 0;
  }

  async deleteConnectionBetweenNodes(sourceId: number, targetId: number): Promise<boolean> {
    const result = await db
      .delete(connections)
      .where(
        or(
          and(eq(connections.sourceId, sourceId), eq(connections.targetId, targetId)),
          and(eq(connections.sourceId, targetId), eq(connections.targetId, sourceId))
        )
      );
    return (result.rowCount || 0) > 0;
  }
}

export const storage = new DatabaseStorage();
