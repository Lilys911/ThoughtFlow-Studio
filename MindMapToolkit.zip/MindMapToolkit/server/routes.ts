import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertNodeSchema, insertConnectionSchema, updateNodeSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all nodes
  app.get("/api/nodes", async (req, res) => {
    try {
      const nodes = await storage.getNodes();
      res.json(nodes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch nodes" });
    }
  });

  // Get single node
  app.get("/api/nodes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const node = await storage.getNode(id);
      if (!node) {
        return res.status(404).json({ message: "Node not found" });
      }
      res.json(node);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch node" });
    }
  });

  // Create node
  app.post("/api/nodes", async (req, res) => {
    try {
      const validatedData = insertNodeSchema.parse(req.body);
      const node = await storage.createNode(validatedData);
      res.status(201).json(node);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid node data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create node" });
    }
  });

  // Update node
  app.put("/api/nodes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = updateNodeSchema.parse({ ...req.body, id });
      const node = await storage.updateNode(validatedData);
      if (!node) {
        return res.status(404).json({ message: "Node not found" });
      }
      res.json(node);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid node data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update node" });
    }
  });

  // Delete node
  app.delete("/api/nodes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteNode(id);
      if (!deleted) {
        return res.status(404).json({ message: "Node not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete node" });
    }
  });

  // Search nodes
  app.get("/api/nodes/search/:query", async (req, res) => {
    try {
      const query = req.params.query;
      const nodes = await storage.searchNodes(query);
      res.json(nodes);
    } catch (error) {
      res.status(500).json({ message: "Failed to search nodes" });
    }
  });

  // Get all connections
  app.get("/api/connections", async (req, res) => {
    try {
      const connections = await storage.getConnections();
      res.json(connections);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch connections" });
    }
  });

  // Get connections for a specific node
  app.get("/api/nodes/:id/connections", async (req, res) => {
    try {
      const nodeId = parseInt(req.params.id);
      const connections = await storage.getNodeConnections(nodeId);
      res.json(connections);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch node connections" });
    }
  });

  // Create connection
  app.post("/api/connections", async (req, res) => {
    try {
      const validatedData = insertConnectionSchema.parse(req.body);
      const connection = await storage.createConnection(validatedData);
      res.status(201).json(connection);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid connection data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create connection" });
    }
  });

  // Delete connection
  app.delete("/api/connections/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteConnection(id);
      if (!deleted) {
        return res.status(404).json({ message: "Connection not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete connection" });
    }
  });

  // Delete connection between specific nodes
  app.delete("/api/connections/between/:sourceId/:targetId", async (req, res) => {
    try {
      const sourceId = parseInt(req.params.sourceId);
      const targetId = parseInt(req.params.targetId);
      const deleted = await storage.deleteConnectionBetweenNodes(sourceId, targetId);
      if (!deleted) {
        return res.status(404).json({ message: "Connection not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete connection" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
